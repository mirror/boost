Currently, this library only includes stuff to access directories in a
platform independent way (however, the code implementing this feature
is, of course, platform dependent). In the future, this library should
include more components.

To have additional componants be included, please sent them to the C++
Boost mailing list (see <http://www.boost.org/>). However, make sure
that all submissions contain an appropriate copyright notice and include
appropriate documentation (see the above mentioned URL for guidelines).

UNIX installation:

  Currently, the UNIX installation requires GNU make. This might be
  considered to be a bug but it is convenient for now...

    ./configure [--prefix=install-dir]
    make
    make install

  There is no testsuite (yet). A simple test of the directory stuff
  can be made like this:

    make src/dir_it_tst
    src/dir_it_tst

  This should produce a directory listing somewhat similiar to
  "ls -l" but with fewer fields (only the directory field, user
  access rights, size, modification time, and name are shown;
  these are the file attributes present on all platforms).

WinNT installation:
